package com.mycompany.ejercicio;

import com.mycompany.ejercicio.Alumno;
import com.mycompany.ejercicio.Curso;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.SessionFactoryBuilder;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class Ejercicio {

    public static void main(String[] args) {
        StandardServiceRegistryBuilder sb = new StandardServiceRegistryBuilder();

        StandardServiceRegistry sr = sb.configure().build();

        MetadataSources ms = new MetadataSources(sr);
        Metadata metadata = ms.getMetadataBuilder().build();
        SessionFactoryBuilder sessionFactoryBuilder = metadata.getSessionFactoryBuilder();

        SessionFactory sf = sessionFactoryBuilder.build();

        Session s = sf.openSession();

        s.beginTransaction();
        
        
        
        s.getTransaction().commit();
    }
    
}
