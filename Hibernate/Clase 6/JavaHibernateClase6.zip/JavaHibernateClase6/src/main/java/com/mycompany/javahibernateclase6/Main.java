package com.mycompany.javahibernateclase6;

import com.mycompany.javahibernateclase6.Post;
import com.mycompany.javahibernateclase6.Comment;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.SessionFactoryBuilder;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class Main {

    public static void main(String[] args) {
        StandardServiceRegistryBuilder sb = new StandardServiceRegistryBuilder();

        StandardServiceRegistry sr = sb.configure().build();

        MetadataSources ms = new MetadataSources(sr);
        Metadata metadata = ms.getMetadataBuilder().build();
        SessionFactoryBuilder sessionFactoryBuilder = metadata.getSessionFactoryBuilder();

        SessionFactory sf = sessionFactoryBuilder.build();

        Session s = sf.openSession();

        s.beginTransaction();
        
        Post p = new Post();
                
        Comment c1 = new Comment();
        Comment c2 = new Comment();
        Comment c3 = new Comment();
        
        p.addComment(c1);
        p.addComment(c2);
        p.addComment(c3);
        
        /* Sólo los utilizo si no uso el CASCADE.
        s.saveOrUpdate(c1);
        s.saveOrUpdate(c2);
        s.saveOrUpdate(c3);
        */
        
//        c1.setPosts(p);
//        c2.setPosts(p);
//        c3.setPosts(p);
        
        s.saveOrUpdate(p);
        
        s.getTransaction().commit();
    }
}
