package com.mycompany.javahibernateclase6;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "comments")
public class Comment {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String comment;
    
//    @ManyToOne(cascade = CascadeType.ALL)
//    private Post posts;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

//    public Post getPosts() {
//        return posts;
//    }
//
//    public void setPosts(Post posts) {
//        this.posts = posts;
//    }
}
