package clase1.pojos;

import java.io.Serializable;

public class concesionarios implements Serializable {
    
}
