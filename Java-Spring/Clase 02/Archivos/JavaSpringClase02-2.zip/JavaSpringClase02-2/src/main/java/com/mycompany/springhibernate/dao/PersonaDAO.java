package com.mycompany.springhibernate.dao;

import com.mycompany.springhibernate.model.Persona;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public class PersonaDAO {
    
    @Autowired
    private SessionFactory sf;
    
    public void Persistir(Persona p) {
        Session session = sf.getCurrentSession();
        
        session.saveOrUpdate(p);
        
    }
}
