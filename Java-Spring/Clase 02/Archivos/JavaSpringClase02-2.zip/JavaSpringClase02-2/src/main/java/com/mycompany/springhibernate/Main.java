package com.mycompany.springhibernate;

import com.mycompany.springhibernate.config.Config;
import com.mycompany.springhibernate.dao.PersonaDAO;
import com.mycompany.springhibernate.model.Persona;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {
    public static void main(String[] args) {
        ApplicationContext applicationContext = new AnnotationConfigApplicationContext(Config.class);
        
        PersonaDAO dao = applicationContext.getBean(PersonaDAO.class);
        
        Persona p = new Persona();
        p.setNombre("Pedro Picapiedras");
                
        dao.Persistir(p);
    }
}
