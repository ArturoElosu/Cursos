package com.mycompany.hibernate;

import com.mycompany.hibernate.model.Persona;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class Main {

    public static void main(String[] args) {
        StandardServiceRegistry registry = new StandardServiceRegistryBuilder().configure().build();
        
        MetadataSources metadata = new MetadataSources(registry);
        SessionFactory sf = metadata.buildMetadata().buildSessionFactory();
        
        Session session = sf.openSession();
        
        Persona p1 = new Persona();
        Persona p2 = new Persona();
        
        p1.setNombre("Cosme Fulanito");
        p2.setNombre("Sancho Panza");
        
        session.beginTransaction();
        
        session.saveOrUpdate(p1);
        session.saveOrUpdate(p2);
        
        session.getTransaction().commit();
        
        session.close();
        sf.close();
    }
    
}
