# spring-data-jpa-beginners
Learning Spring Data [JPA]
