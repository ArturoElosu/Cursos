# spring-data-jpa-rest-beginners
Learning Spring Data Rest [JPA]
