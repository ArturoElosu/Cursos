console.log('Ajax Concatenado')


// ------------------------
// PEDIDO AJAX con Promesas
// ------------------------
function getComentarioPromesa(num) {
    return new Promise((resolve, reject) => {
        let xhr = new XMLHttpRequest
        xhr.open('get', 'https://jsonplaceholder.typicode.com/comments/' + num)
        xhr.addEventListener('load', () => {
            if(xhr.status == 200) {
                let respuesta = JSON.parse(xhr.response)
                //console.log(respuesta)
                resolve(respuesta)
            }
            else {
                let error = {
                    type: 'Error status ajax',
                    body: xhr.status
                }
                reject(error)                
            }
        })
        xhr.addEventListener('error', e => {
            let error = {
                type: 'Error gral ajax',
                body: e
            }
            reject(error)
        })
        xhr.send()
    })
}
/*getComentarioPromesa(1)
.then(respuesta => getComentarioPromesa(2))
.then(respuesta => getComentarioPromesa(3))
.then(respuesta => getComentarioPromesa(4))
.then(respuesta => getComentarioPromesa(5))
.then(respuesta => getComentarioPromesa(6))
.then(respuesta => getComentarioPromesa(7))
.then(respuesta => getComentarioPromesa(8))
.catch( error => console.log('ERROR!!!', error))
*/

async function getComentarios() {

    try {
        let r = await getComentarioPromesa(1)
        console.log(r)

        r = await getComentarioPromesa(2)
        console.log(r)
        
        r = await getComentarioPromesa(3)
        console.log(r)

        r = await getComentarioPromesa(4)
        console.log(r)

        r = await getComentarioPromesa(5000)
        console.log(r)

        r = await getComentarioPromesa(6)
        console.log(r)

        r = await getComentarioPromesa(7)
        console.log(r)

        r = await getComentarioPromesa(8)
        console.log(r)
    }
    catch(e) {
        console.log('ERROR!!!', e)
    }
}
//getComentarios()

function getComentarioFetch(num, debug) {
    return fetch('https://jsonplaceholder.typicode.com/comments/' + num)
    .then(response => {
        //console.log(response)
        return response.json()
    })
    .then(json => {
        if(debug) console.log(json)
        return Promise.resolve(json)
    })
}


function getComentariosFetch() {
    /*
    getComentarioFetch(1, true)
    .then(() => getComentarioFetch(2, true))    
    .then(() => getComentarioFetch(3, true))    
    .then(() => getComentarioFetch(4, true))    
    .then(() => console.log('Fin!'))
    */
    getComentarioFetch(1, !true)
    .then(respuesta => {console.log(respuesta); return getComentarioFetch(2, !true)})    
    .then(respuesta => {console.log(respuesta); return getComentarioFetch(3, !true)})    
    .then(respuesta => {console.log(respuesta); return getComentarioFetch(4, !true)})    
    .then(respuesta => console.log(respuesta))
    .catch( error => console.log('ERROR!!!', error))
}
//getComentariosFetch()

/*
async function getComentariosFetchAsyncAwait() {
    try {
        await getComentarioFetch(1, true)
        await getComentarioFetch(2, true)
        await getComentarioFetch(3, true)
        await getComentarioFetch(4, true)
    }
    catch(error) {
        console.log('ERROR!!!', error)
    }
}*/

const delay = (id,ms) => new Promise((resolve,reject) => setTimeout(resolve,ms,'Fin del retardo '+id))

Promise.race([delay(1,6000), delay(2,3000), delay(3,7000)])
.then(console.log)

Promise.all([delay(1,6000), delay(2,3000), delay(3,7000)])
.then(console.log)


async function getComentariosFetchAsyncAwait() {
    try {
        let r = await getComentarioFetch(1, !true)
        console.log(r)

        r = await getComentarioFetch(2, !true)
        console.log(r)

        let mensaje = await delay(0,5000)
        console.log(mensaje)

        r = await getComentarioFetch(3, !true)
        console.log(r)    

        r = await getComentarioFetch(4, !true)
        console.log(r)

    }
    catch(error) {
        console.log('ERROR!!!', error)
    }
}
getComentariosFetchAsyncAwait()


/*
// ------------------------
// PEDIDO AJAX con callback
// ------------------------
function getComentarioCallback(num, cb) {
    let xhr = new XMLHttpRequest
    xhr.open('get', 'https://jsonplaceholder.typicode.com/comments/' + num)
    xhr.addEventListener('load', () => {
        if(xhr.status == 200) {
            let respuesta = JSON.parse(xhr.response)
            console.log(respuesta)
            if(cb) cb(respuesta)
        }
    })
    xhr.send()
}

getComentarioCallback(1, respuesta => {
    getComentarioCallback(2, respuesta => {
        getComentarioCallback(3, respuesta => {
            getComentarioCallback(4, respuesta => {
                getComentarioCallback(5, respuesta => {
                    getComentarioCallback(6, respuesta => {
                        getComentarioCallback(7, respuesta => {
                            getComentarioCallback(8, respuesta => {

                            })
                        })
                    })
                })
            })
        })
    })
})
*/




// -------------
// PEDIDO 1 AJAX
// -------------
function getComentario1() {
    let xhr = new XMLHttpRequest
    xhr.open('get', 'https://jsonplaceholder.typicode.com/comments/' + '1')
    xhr.addEventListener('load', () => {
        if(xhr.status == 200) {
            let respuesta = JSON.parse(xhr.response)
            console.log(respuesta)
            getComentario2()
        }
    })
    xhr.send()
}

// -------------
// PEDIDO 2 AJAX
// -------------
function getComentario2() {
    let xhr = new XMLHttpRequest
    xhr.open('get', 'https://jsonplaceholder.typicode.com/comments/' + '2')
    xhr.addEventListener('load', () => {
        if(xhr.status == 200) {
            let respuesta = JSON.parse(xhr.response)
            console.log(respuesta)
            getComentario3()
        }
    })
    xhr.send()
}

// -------------
// PEDIDO 3 AJAX
// -------------
function getComentario3() {
    let xhr = new XMLHttpRequest
    xhr.open('get', 'https://jsonplaceholder.typicode.com/comments/' + '3')
    xhr.addEventListener('load', () => {
        if(xhr.status == 200) {
            let respuesta = JSON.parse(xhr.response)
            console.log(respuesta)
        }
    })
    xhr.send()
}

//getComentario1()
