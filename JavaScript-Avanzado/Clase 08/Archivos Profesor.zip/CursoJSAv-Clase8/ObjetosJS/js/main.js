console.log('Objetos JS')

if(false) {
// ----------------------------------
//CREACIÓN DE OBJETO EN FORMA LITERAL
// ----------------------------------
let a = {nombre: 'Juan'}
console.log(a.hasOwnProperty('nombre'))
console.log(a.hasOwnProperty('edad'))

// ---------------------------------------------
//CREACIÓN DE OBJETO UTILIZANDO EL MÉTODO CREATE
// ---------------------------------------------
let prototipo1 = {
    saludo : function() {
        console.log('Hola')
    }
}

let prototipo2 = {
    saludo2 : function() {
        console.log('Hola 2')
    }
}


let b = Object.create(prototipo1)
b.saludo()
let c = Object.create(prototipo2)
c.saludo2()

console.log(prototipo1.isPrototypeOf(b))
console.log(prototipo2.isPrototypeOf(b))
console.log(prototipo2.isPrototypeOf(c))

// -----------------------------------------------------
//CONFIGURACIÓN AVANZADA DE LAS PROPIEDADES DE UN OBJETO
// -----------------------------------------------------
//let d = {x:1}
let prototipo3 = Object.create(null,{
    saludo3 : {
        value : function() {
            console.log('Hola3')
        },
        writable: !false,
        configurable: !false,
        enumerable: !false
    }
})

let d = Object.create(prototipo3,{
    x: {
        value: 1,
        writable: false, //d.x = 10
        configurable: !false, //delete d.x
        enumerable: !false //for(let key in d){console.log(key)}
    },
    y: {
        value: 22,
        writable: false,
        configurable: !false,
        enumerable: !false
    },
    saludo: {
        value: function() {console.log('Holaaaa!')},
        writable: false,
        configurable: !false,
        enumerable: !false
    }

})
// --------------------------------------------
// FUNCIONES: scope, ambito, closure, contexto
// --------------------------------------------

//-------------
//scope, ambito
//-------------
function foo() {

}

console.dir(foo)
foo.x = true
console.log(foo.x)


function sumar(a,b) {
    return ((typeof a != 'undefined')?a:0) +
    ((typeof b != 'undefined')? b:0)
}

console.log(sumar(5,7))

var a1 = 2
function foo2(c) {
    var b = 10
    console.log(a1, b, c)
}

foo2(30)


//--------
//closure
//--------
function externa(x) {
    //console.log(x)
    return function interna(y) {
        console.log(y)
    }
}

var resultado = externa(50)
resultado(10)
//console.log(x)

//--------
//contexto
//--------

function foo3() {
    console.log(this)
}
foo3()

var persona = {
    nombre: 'Juan',
    saludo : function() {
        console.log(this)
    }
}

persona.saludo()
} // fin!!!!

function ctx(a,b) {
    console.log(this,a,b)
}

ctx(4,5)
ctx.apply({x:1},[4,5])
ctx.call({x:1},4,5)

// ----------------------------------------------------
//CREACIÓN DE OBJETO UTILZANDO UNA FUNCIÓN CONSTRUCTORA
// ----------------------------------------------------


















