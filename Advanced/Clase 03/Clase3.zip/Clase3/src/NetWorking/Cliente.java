package NetWorking;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Cliente {
    
    public static void main(String[] args) {
        try {/*
//            Socket socket = new Socket("Instructor-402", 4000); // Para mandarle al "Servidor" de la pc del profesor.
            
            Socket socket = new Socket("localhost", 4000);
            
            OutputStream os = socket.getOutputStream();
            
            DataOutputStream dos = new DataOutputStream(os);
            
            dos.writeUTF("Hello World From Client 402-04");*/
            
            Socket socket = new Socket("localhost", 4000);
            
            OutputStream os = socket.getOutputStream();
            
            Persona p = new Persona();
            
            p.setNombre("Cosme Fulanito");
            p.setEdad(99);
            
            ObjectOutputStream oos = new ObjectOutputStream(os);
            
            oos.writeObject(p);
            
        } catch (IOException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
