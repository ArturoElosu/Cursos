package NetWorking;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Servidor {
    public static void main(String[] args) {
        try {
//            ServerSocket server = new ServerSocket(4000);
//            
//            System.out.println("Antes de aceptar");
//            
//            Socket client = server.accept();
//            
//            System.out.println("Luego de aceptar");
//            
//            InputStream is = client.getInputStream();
//            
//            DataInputStream dis = new DataInputStream(is);
//            
//            String mensaje = dis.readUTF();
//            
//            System.out.println(mensaje);
            
            ServerSocket server = new ServerSocket(4000);
            
            System.out.println("Antes de aceptar");
            
            Socket client = server.accept();
            
            System.out.println("Luego de aceptar");
            
            InputStream is = client.getInputStream();
            
            ObjectInputStream ois = new ObjectInputStream(is);
            
            try{
                Object myObject = ois.readObject();
                
                System.out.println(myObject);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);
            }
                    
                    
        } catch (IOException ex) {
            Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
