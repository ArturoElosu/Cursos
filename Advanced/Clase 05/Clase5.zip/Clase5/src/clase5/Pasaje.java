package clase5;

public class Pasaje {
    
    
    private Estado estado;
}
