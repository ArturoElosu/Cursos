package clase5;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Generics {
    public static void main(String[] args) {
        List<Persona> p = new ArrayList<>();
        List<Empleado> e = new ArrayList<>();
        
        PersonaComparator pc = new PersonaComparator();
        EmpleadoComparator ec = new EmpleadoComparator();
    
        Collections.sort(p, pc);
        
        Collections.sort(e, pc);
        Collections.sort(e, ec);
    }
}
