package clase5;

import java.util.concurrent.TimeUnit;

public class Ejemploç {
    
    public static void main(String[] args) {
        ejecutar(Actividades.SALTAR);
    }
    
    public static void ejecutar(Actividades n) {  
        n.ejecutar();
    }
}
