/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase5;

/**
 *
 * @author EducaciónIT
 */
public class MainPasaje {
    public static void main(String[] args) {
        Estado e = Estado.NEW;
        
        System.out.println(e);
        e = e.next(false);
        System.out.println(e);
        e = e.next(false);
        System.out.println(e);
        e = e.prev();
        System.out.println(e);
        e = e.next(true);
        System.out.println(e);
        e.next(true);
    }
}
