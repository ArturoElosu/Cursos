/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase5;

import java.util.Comparator;

/**
 *
 * @author EducaciónIT
 */
public class EmpleadoComparator implements Comparator<Empleado>{

    @Override
    public int compare(Empleado o1, Empleado o2) {
        return o1.sueldo > o2.sueldo ? 1: -1;
    }
    
}
