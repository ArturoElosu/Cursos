package clase5;


public class Foo {

    static {
        System.out.println("Bloque Estatico Foo");
    }
    
    
    
    public Foo() {
        System.out.println("Constructor Foo");
    }
    
    {
        System.out.println("Default Foo");
    }
    
    
    
}
