package clase5;

public class Casteo {
    public static void main(String[] args) {
      
        
    }
    
}
