package clase5;

public enum Actividades {
    CANTAR {
        @Override
        public void ejecutar() {
            System.out.println("Cantando");
        }
        
    }, SALTAR;
    
    public void ejecutar() {
        System.out.println("Random");
    }
}
