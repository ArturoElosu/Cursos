package clase5;

public class CicloDevida {
    
    public static void main(String[] args) {
        Foo f1 = new Bar();
    }
}
