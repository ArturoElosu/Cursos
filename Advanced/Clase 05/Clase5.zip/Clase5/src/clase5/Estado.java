
package clase5;

public enum Estado {
    NEW {
        @Override
        public Estado next(boolean x) {
            return Estado.FACTURACION;
        }
        
    }, FACTURACION {
        @Override
        public Estado next(boolean x) {
            if (x) {
                return Estado.ACEPTADA;
            } else {
                return Estado.RECHAZADO;
            }            
        }
    }, RECHAZADO {
        @Override
        public Estado prev() {
            return Estado.FACTURACION;
        }
        
    }, ACEPTADA;
    
    public Estado next(boolean x) {
        throw new IllegalStateException();
    } 
    
    public Estado prev() {
        throw new IllegalStateException();
    } 
}
