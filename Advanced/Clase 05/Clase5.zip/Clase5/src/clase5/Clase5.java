package clase5;

public class Clase5 {

    private int x = 30;
    
    public static void main(String[] args) {
        System.out.println("Hola Mundo");
        Clase5 c = new Clase5();    
        Clase5 c1 = new Clase5();    
        Tarea t = new Tarea();
        Ejemplo ejemplo = c.new Ejemplo();
        Ejemplo ejemplo1 = c1.new Ejemplo();

        c.x = 50;
        // t.ejecutar(10);
        ejemplo.ejecutar(20);
        ejemplo1.ejecutar(20);
    }
    
    private class Ejemplo { 
        
        private int x = 15;
        
        public void ejecutar(int x) {
            System.out.println("Soy: " + x);
            System.out.println("Soy: " + this.x);
            System.out.println("Soy: " + Clase5.this.x);
        }
    }
    private static class Tarea { 
        
        private int x = 15;
        
        public void ejecutar(int x) {
            System.out.println("Soy: " + x);
            System.out.println("Soy: " + this.x);
        }
    }
    
}
