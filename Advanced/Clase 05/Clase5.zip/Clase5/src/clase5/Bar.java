package clase5;

import java.util.ArrayList;
import java.util.List;

public class Bar extends Foo{

    static {
        System.out.println("Bloque Estatico Bar");
    }
    
    {
        System.out.println("Default Bar");
    }
    
    public Bar() {
        System.out.println("Constructor Bar");
    }
}
