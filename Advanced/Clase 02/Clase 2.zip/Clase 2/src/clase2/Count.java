package clase2;

import java.util.concurrent.CountDownLatch;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Count {
    public static void main(String[] args) {
        CountDownLatch cd1 = new CountDownLatch(2);
        
        Tarea t1 = new Tarea(cd1);
        Tarea t2 = new Tarea(cd1);
        
        t1.start();
        t2.start();
        
        try {
            cd1.await();
        } catch (InterruptedException ex) {
            Logger.getLogger(Count.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        System.out.println("Programa terminado");
    }
    
    private static class Tarea extends Thread {
        
        CountDownLatch cd1;
        private Tarea(CountDownLatch cd1) {
            this.cd1 = cd1;
        }
        
        @Override
        public void run(){
            System.out.println("Hola");
            cd1.countDown();
        }
    }
}
