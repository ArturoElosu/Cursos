package clase2;

import java.util.logging.Level;
import java.util.logging.Logger;

public class Ejemplo {

    public static void main(String[] args) {
        Meeting meeting = new Meeting();

        Jefe j1 = new Jefe("Jefe", meeting);
        Empleado e1 = new Empleado("Cosme Fulanito", meeting);
        Empleado e2 = new Empleado("Sancho Panza", meeting);
        Empleado e3 = new Empleado("Pablo Marmol", meeting);

        new Thread(e1).start();
        new Thread(e2).start();
        new Thread(e3).start();

        try {
            Thread.sleep(2000);
        } catch (InterruptedException ex) {
            Logger.getLogger(Ejemplo.class.getName()).log(Level.SEVERE, null, ex);
        }

        new Thread(j1).start();

    }

    private static class Meeting {

        public synchronized void esperar(String nombre) {
            System.out.println(nombre + " esta esperando");
            try {
                wait();
            } catch (InterruptedException ex) {
                Logger.getLogger(Ejemplo.class.getName()).log(Level.SEVERE, null, ex);
            }
            System.out.println(nombre + " dijo, buenos dias jefe");
            notify();
        }

        public synchronized void empezar() {
            System.out.println("Buenos dias esclavos");
            notify();
        }

    }

    private static class Empleado implements Runnable {

        private String nombre;
        private Meeting meeting;

        public Empleado(String nombre, Meeting meeting) {
            this.nombre = nombre;
            this.meeting = meeting;
        }

        @Override
        public void run() {
            meeting.esperar(nombre);
        }
    }

    private static class Jefe implements Runnable {

        private String nombre;
        private Meeting meeting;

        public Jefe(String nombre, Meeting meeting) {
            this.nombre = nombre;
            this.meeting = meeting;
        }

        @Override
        public void run() {
            meeting.empezar();
        }

    }
}
