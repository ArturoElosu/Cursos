package clase2;

import java.util.logging.Level;
import java.util.logging.Logger;

public class Clase2 {

    public static void main(String[] args) {
        Cuenta c = new Cuenta();

        Persona p1 = new Persona("Cosme Fulanito", c, 1);
        Persona p2 = new Persona("Sancho Panza", c, 2);

        Thread t1 = new Thread(p1);
        Thread t2 = new Thread(p2);

        t1.start();
        t2.start();

        try {
            t1.join();
            t2.join();
        } catch (InterruptedException ex) {
            Logger.getLogger(Clase2.class.getName()).log(Level.SEVERE, null, ex);
        }

        System.out.println("El saldo es:" + c.getSaldo());
    }

    private static class Cuenta {

        private double saldo;

        public double getSaldo() {
            return saldo;
        }

        private synchronized void acreditar(double saldo) {
            this.saldo += saldo;
        }

        public synchronized void debitar(double saldo) {
            this.saldo -= saldo;
        }

    }

    private static class Persona implements Runnable {

        private String nombre;

        private Cuenta cuenta;

        private int accion;

        public Persona(String nombre, Cuenta cuenta, int accion) {
            this.nombre = nombre;
            this.cuenta = cuenta;
            this.accion = accion;
        }

        @Override
        public void run() {
            System.out.println(nombre);
            if (accion == 1) {
                cuenta.acreditar(100);
            } else {
                cuenta.debitar(50);
            }
        }
    }
}
