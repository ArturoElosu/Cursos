package clase2;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Pool {
    
    public static void main(String[] args) {
        ExecutorService pool = Executors.newFixedThreadPool(4);
        
        pool.execute(new Tarea());
        pool.execute(new Tarea());
        pool.execute(new Tarea());
        pool.execute(new Tarea());
        
        pool.shutdown(); /* Sirve para terminar el Pool de Threads. */
    }
    
    private static class Tarea implements Runnable {

        @Override
        public void run() {
            try {
                System.out.println("Hello World: " + Thread.currentThread());
                Thread.sleep(1);
            } catch (InterruptedException ex) {
                Logger.getLogger(Pool.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    
    }
}
