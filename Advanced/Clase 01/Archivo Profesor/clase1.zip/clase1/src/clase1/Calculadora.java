package clase1;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Calculadora {
    
    public static AtomicInteger contador = new AtomicInteger(0);
    
        
    public static void main(String[] args) {
        System.out.println("Inicio");
        Contador c1 = new Contador();
        Contador c2 = new Contador();
        c1.start();
        c2.start();

        try {
            
            c1.join();
            c2.join();
        } catch (InterruptedException ex) {
            Logger.getLogger(Calculadora.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("Total: " + contador);
    }
    
    private static class Contador extends Thread {

        @Override
        public void run() {
            for (int i = 0; i < 10000; i++) {
                contador.incrementAndGet();
            }
        }
        
    }
}
