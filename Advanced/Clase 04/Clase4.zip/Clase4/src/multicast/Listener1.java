package multicast;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Listener1 {
    public static void main(String[] args) {
        try {
            MulticastSocket ms = new MulticastSocket(10000);
            
            ms.joinGroup(InetAddress.getByName("224.4.8.0"));
            ms.joinGroup(InetAddress.getByName("224.8.8.0"));
            
            byte[] buffer = new byte[100];
            DatagramPacket dp = new DatagramPacket(buffer, buffer.length);
            
            System.out.println("Antes");
            
            ms.receive(dp);
            
            System.out.println("Despues");
            
            System.out.println(new String(dp.getData()));
        } catch (IOException ex) {
            Logger.getLogger(Listener1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
