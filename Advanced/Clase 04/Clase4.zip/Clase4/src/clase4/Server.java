package clase4;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Server {

    public static void main(String[] args) {
        try {
            ServerSocket server = new ServerSocket(4000);
            
            Socket client = server.accept();
            
            InputStream is = client.getInputStream();
//            ObjectInputStream ois = new ObjectInputStream(is);
            
            FileOutputStream fos = new FileOutputStream("datos_backup.txt");
            
            byte[] buffer = new byte[5];
            
            int leido = is.read(buffer);
            
            while (leido != -1) {
                fos.write(buffer,0,leido);
                leido = is.read(buffer);
            }
            
//            Persona p = (Persona) ois.readObject();
            
//            System.out.println(p);
        } catch (IOException ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
        }/* catch (ClassNotFoundException ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
        }*/
        
        
    }
    
}
