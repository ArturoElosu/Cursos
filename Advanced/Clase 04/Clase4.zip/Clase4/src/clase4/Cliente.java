package clase4;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Cliente {

    public static void main(String[] args) {
        try {
            Socket s = new Socket("localhost", 4000);
//            Socket s = new Socket("Instructor-402", 4000);
            
            OutputStream os = s.getOutputStream();
//            ObjectOutputStream oos = new ObjectOutputStream(os);
            
            FileInputStream fis = new FileInputStream("datos.txt");
            
            int data = fis.read();
            
            while (data != -1){
                os.write(data);
                data = fis.read();
            }
            
            Persona p = new Persona();
            
            p.setNombre("Cosme Fulanito");
            
//            oos.writeObject(p);

            s.close();
        } catch (IOException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
    
}
