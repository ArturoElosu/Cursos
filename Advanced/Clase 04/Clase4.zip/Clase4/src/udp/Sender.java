package udp;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Sender {
    public static void main(String[] args) {
        try {
            DatagramSocket s = new DatagramSocket();
            
            byte[] message = "Hello World".getBytes();
            
            DatagramPacket dp = new DatagramPacket(message, message.length, InetAddress.getLocalHost(), 6000);
            
            s.send(dp);
            
        } catch (SocketException ex) {
            Logger.getLogger(Sender.class.getName()).log(Level.SEVERE, null, ex);
        } catch (UnknownHostException ex) {
            Logger.getLogger(Sender.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Sender.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
