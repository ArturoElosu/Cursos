package udp;

import java.io.IOException;
import java.io.PipedInputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Listener {
    public static void main(String[] args) {
        try {
            DatagramSocket ds = new DatagramSocket(6000);
            
            byte[] buffer = new byte[100];
            DatagramPacket dp = new DatagramPacket(buffer, buffer.length);
            
            System.out.println("Antes");
            ds.receive(dp);            
            
            System.out.println(new String(dp.getData()));
            System.out.println(dp.getPort());            
            System.out.println(dp.getSocketAddress());
            System.out.println("Despues");
            
            
        } catch (SocketException ex) {
            Logger.getLogger(Sender.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Sender.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
