package clase4;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.Socket;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Cliente {

    public static void main(String[] args) {
        try {

            Socket s = new Socket(InetAddress.getLocalHost(), 4000);

            InputStream is = s.getInputStream();

            FileOutputStream fos = new FileOutputStream("datos_backup_" + new Random().nextInt(1000) + ".txt");

            byte[] buffer = new byte[5];

            int leido = is.read(buffer);

            while (leido != -1) {
                fos.write(buffer, 0, leido);
                leido = is.read(buffer);
            }

        } catch (IOException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
