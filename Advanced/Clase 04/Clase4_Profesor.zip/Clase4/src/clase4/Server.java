package clase4;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Server {

    public static void main(String[] args) {
        try {
            ExecutorService scheduler = Executors.newFixedThreadPool(5);
            ServerSocket server = new ServerSocket(4000);

            while (true) {
                Socket client = server.accept();
                scheduler.submit(new EnviadorArchivo(client));                
            }

        } catch (IOException ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    
    private static class EnviadorArchivo implements Runnable {

        private Socket client;
        
        public EnviadorArchivo(Socket client) {
            this.client = client;
        }
        @Override
        public void run() {
            FileInputStream fis = null;
            try {
                OutputStream os = client.getOutputStream();
                fis = new FileInputStream("datos.txt");
                int data = fis.read();
                while (data != -1) {
                    os.write(data);
                    data = fis.read();
                }
                client.close();
            } catch (FileNotFoundException ex) {
                Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
            } finally {
                try {
                    fis.close();
                } catch (IOException ex) {
                    Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        
    }

}
