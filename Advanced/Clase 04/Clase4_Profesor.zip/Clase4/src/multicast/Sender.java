package multicast;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Sender {
    public static void main(String[] args) {
        try {
            DatagramSocket ds = new DatagramSocket();
            
            byte[] message = "Soy el sender".getBytes();
            DatagramPacket dp = new DatagramPacket(
                    message,
                    message.length,
                    InetAddress.getByName("224.4.8.0"),
                    10000);
            
            ds.send(dp);
        } catch (UnknownHostException ex) {
            Logger.getLogger(Sender.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Sender.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
}
