package ar.com.crs;

public class Main {
    public static void main(String[] args) {
        Cliente c = new Cliente();
        String response = c.getXml();
        System.out.println("Resp: " + response);
    }
}
