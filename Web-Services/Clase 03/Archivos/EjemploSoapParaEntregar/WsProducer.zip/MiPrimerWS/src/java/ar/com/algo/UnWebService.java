/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.algo;

import javax.jws.Oneway;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

/**
 *
 * @author cflores
 */
@WebService(serviceName="MiPrimerWS")
public class UnWebService {
    
       
    @WebMethod(operationName = "saludar")
    public String saludar(String nombre) {
        
        return nombre + ", saludos!!!";
        
    }
    @WebMethod(operationName = "obtenerInformacionCliente")
    public Cliente obtenerCliente(@WebParam(name="legajo")int legajo) throws Exception{
        
        if(legajo != 21){
            //devuelvo como respuesta la informacion de un cliente
            return new Cliente("Carlos", "Gonzalez", 345);
        }else{
           //simulo devolver un error, lanzando una exception 
           throw new Exception("Ocurrio un error al buscar el cliente");
        }
        
    }
    
    @WebMethod(operationName = "decirHola")
    @Oneway()
    public void decirHola(String param) {
        System.out.println("Se llamo al metodo decirHola()....." + param);
                
    }
        
    
    // la url donde se puede obtener el wsdl es http://localhost:8080/MiPrimerWS/MiPrimerWS?wsdl
}
