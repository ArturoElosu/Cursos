/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package consumidordesdejava;

import ar.com.wss.Cliente;
import ar.com.wss.Exception_Exception;
import ar.com.wss.MiPrimerWS;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author cflores
 */
public class ConsumidorDesdeJava {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //////////////////////////////
       //invocamos al metodo Saludar//
       //////////////////////////////
        String saludo = new MiPrimerWS().getUnWebServicePort().saludar("Carlos ");
        System.out.println("La respuesta es: " + saludo);
        
        
       //////////////////////////////////////////////////////////////// 
       //obtenemos informacion del cliente(respuesta devuelve cliente)/
       ////////////////////////////////////////////////////////////////
       Cliente c1 = null;
        try {
            c1 = new MiPrimerWS().getUnWebServicePort().obtenerInformacionCliente(22);
        } catch (Exception_Exception ex) {
            Logger.getLogger(ConsumidorDesdeJava.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("El nombre del cliente es: " + c1.getNombre());
       
        
        
        ////////////////////////////////////////////////////////////////
        //obtenemos informacion del cliente(respuesta devuelve error)///
        ////////////////////////////////////////////////////////////////
        try {
            
            Cliente c2 = new MiPrimerWS().getUnWebServicePort().obtenerInformacionCliente(21);
            System.out.println("El cliente es: " + c2);
        } catch (Exception_Exception ex) {
            System.out.println("Ocurrio un error al consumir el servicio : " + ex);
        }
               
    }
    
}
