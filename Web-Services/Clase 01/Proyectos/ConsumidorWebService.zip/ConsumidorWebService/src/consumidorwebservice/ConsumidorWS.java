package consumidorwebservice;

import ar.com.educacionit.MiPrimerWS;

public class ConsumidorWS {
    
    public static void main(String[] args) {
        
        String respuesta = new MiPrimerWS().getMiPrimerServicioPort().saludarOp("Cesar");
        
        System.out.println("La respuesta es: " + respuesta);
    }
    
}
