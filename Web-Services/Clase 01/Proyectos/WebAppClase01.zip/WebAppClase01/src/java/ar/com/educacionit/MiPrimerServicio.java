package ar.com.educacionit;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

@WebService(serviceName = "MiPrimerWS")
public class MiPrimerServicio {
    @WebMethod(operationName = "saludarOp")
    public String saludar(@WebParam(name="nombre") String nombre){
        return "Saludos " + nombre +  "!!";
    }
    
}
