package ar.com.educacionit;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

@WebService(serviceName = "clienteWS")
public class MiWs {
    
    @WebMethod(operationName = "obtenerCliente")
    public Cliente getInfoCliente( @WebParam(name = "legajo") int legajo) throws Exception{
        
        if(legajo != 21){
            return new Cliente("Cesar", "Flores", 23546);
        } else{
            throw new Exception("Hubo un error al obtener el cliente.");
        }
    }
}
