package clientesoapui;

import ar.com.Cliente;
import ar.com.ClienteWS;
import ar.com.Exception_Exception;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ClienteSoapUI {

    public static void main(String[] args) throws MalformedURLException {
        try {
            URL url = new URL("https://nuevoEndpoint.");
            Cliente c = new ClienteWS(url).getMiWsPort().obtenerCliente(23);
            System.out.println("Nombre: " + c.getNombre() + " Apellido: " + c.getApellido());
        } catch (Exception_Exception ex) {
            Logger.getLogger(ClienteSoapUI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
