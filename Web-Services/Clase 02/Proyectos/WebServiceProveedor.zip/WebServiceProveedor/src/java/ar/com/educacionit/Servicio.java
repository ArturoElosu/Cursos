package ar.com.educacionit;

import ar.com.fiscalgis.solicituddatos.response.LoginResponse;
import ar.com.fiscalgis.solicituddatos.response.Usuario;
import javax.jws.WebService;

@WebService(serviceName = "WebServiceBanking", portName = "WebServiceBankingData_Port", endpointInterface = "com.fiscalgis.webservicebankingdata.WebServiceBankingData", targetNamespace = "http://fiscalgis.com/WebServiceBankingData", wsdlLocation = "WEB-INF/wsdl/Servicio/WsdlBankingData.wsdl")
public class Servicio {

    public ar.com.fiscalgis.solicituddatos.response.LoginResponse obtenerDatos(ar.com.fiscalgis.solicituddatos.request.LoginRequest request) throws com.fiscalgis.webservicebankingdata.MyServiceException {
        
        LoginResponse lr = new LoginResponse();
        LoginResponse.Body body = new LoginResponse.Body();
        Usuario u = new Usuario();
        u.setEmail("ceflores@gmail.com");
        body.setUsuario(u);
        lr.setBody(body);
        
        return lr;
    }
    
}
