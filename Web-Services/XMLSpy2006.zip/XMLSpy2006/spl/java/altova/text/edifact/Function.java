[call GenerateFileHeader("Function.java")]
package com.altova.text.edifact;

import com.altova.text.edifact.commands.CommandList;

public class Function extends CommandList {
}